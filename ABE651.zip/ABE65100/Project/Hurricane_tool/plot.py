import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import pandas as pd
import numpy as np
import datetime as dt
from types import SimpleNamespace
import hurricane_tool as ht

#========================================================================
#READING TRACK DATA
#========================================================================
track_file='florence.txt'
data=pd.read_fwf(track_file, sep=" ", header=None) #reading track data
track_lon=-data[5].values #extracting longitude
track_lat=data[4].values #extracting latitude

#Setting projection for track plot
proj = ccrs.Mercator()
ll_proj = ccrs.Geodetic()
bound_lons = [-105, -6.5] #bounding box for plot
bound_lats = [0, 40] # bounding box for plot

fig,ax=ht.plot_track(track_lon,track_lat,proj,ll_proj)  #plotting track 
ax.set_extent(bound_lons+bound_lats, ll_proj) #setting bounding box 



#========================================================================
#READING DATA AND CROPPING DATA (BASED ON BOUNDARY EXTENT)
#========================================================================
pdata=[] #defining dummy data
boundary_extent=10 #boundary extent for each time step (in degrees)
interval=15
for i in range(1,track_lat.shape[0]-1,interval):
	print(i)
	start=np.array([data[3][i],data[2][i]]) #reading specific date to download TRMM/IMERG data
	mdate,md=ht.dates(start) #putting dates in specific format as per function requirement
	#trmm=ht.download_trmm(mdate,md)
	dataset=ht.download_imerg(mdate,md,username='ankurk017',password='AnkurKumar2020') #reading data from OPENDAP
	out=ht.track_data(dataset,track_lon[i],track_lat[i],boundary_extent=boundary_extent) #cropping data as per  boundary extent 
	pdata.append(out.pcpcrop) #appending each timesteps as list



#========================================================================
#PLOTTING RAINFALL ALONG TRACK
#========================================================================
outputdata=np.dstack(pdata) #converting list into matrix
outputdata[outputdata<0.5]=np.nan #skipping negligible value
fig,ax=ht.mycontourf(dataset,np.nanmean(outputdata,axis=2)) #plotting the rainfall
	
