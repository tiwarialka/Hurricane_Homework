## **Contribution of Tropical Cyclones on Rainfall ‘Climatology’ over the south and the southeast US in the recent IMERG-era (2013- 2018)**

Using TRMM data for generating rainfall swath along the track of Hurricane Florence.

Input file is 
> florence.txt which has been grabbed from hurdat_extend.txt.

More details are in submission.
