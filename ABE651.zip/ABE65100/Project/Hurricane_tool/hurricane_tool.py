import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import pandas as pd
import numpy as np
import datetime as dt
from types import SimpleNamespace
def dates(input):
    if len(str(input[1]))==5:
        datefor='0'+str(input[1])
    year=str(input[0])
    month=datefor[0:2]
    date=datefor[2:4]
    hour=datefor[4:6]
    dm = dt.datetime.strptime(year+'.'+month+'.'+date+'.'+hour, '%Y.%m.%d.%H')
    return dm.timetuple(),datefor


def download_trmm(mdate,md,username='dummy',password='dummy'):
	from pydap.client import open_url
	from pydap.cas.urs import setup_session
	import sys
	if username=='dummy':
		sys.exit("ERROR:: Please provide username and password as keyword")
	trmm=SimpleNamespace()
	yyyymmddHH=str(mdate.tm_year)+md[0:2]+md[2:4]+md[4:6]
	julian=mdate.tm_yday-1 if md[4:6]=='00' else mdate.tm_yday
	opendap_url="https://disc2.gesdisc.eosdis.nasa.gov/opendap/TRMM_RT/TRMM_3B42RT.7/2018/"+str(julian)+"/3B42RT."+yyyymmddHH+".7.nc4"
	session = setup_session(username, password, check_url=opendap_url)
	dataset = open_url(opendap_url, session=session)
	trmm.lat=dataset['lat'].data[slice(250,None)]
	trmm.lon=dataset['lon'].data[slice(None,750)]
	pcp=dataset['precipitation'].data[slice(250,None),slice(None,750)]
	pcp[pcp<0]=np.nan
	trmm.pcp=pcp
	return trmm

def download_imerg(mdate,md,username='dummy',password='dummy'):
	from pydap.client import open_url
	from pydap.cas.urs import setup_session
	import sys
	if username=='dummy':
		sys.exit("ERROR: Please provide username and password as keyword")
	imerg=SimpleNamespace()
	yyyymmdd=str(mdate.tm_year)+md[:-2]
	#julian=mdate.tm_yday+1 if md[4:6]=='00' else mdate.tm_yday
	julian=mdate.tm_yday
	string1="S"+md[-2:]+"0000"
	string2="E"+md[-2:]+"2959"

	str3=str(int(md[-2:])*60)
	if len(str3)==1:
	        string3="000"+str3
	elif len(str3)==2:
	        string3="00"+str3
	elif len(str3)==3:
	        string3="0"+str3
	elif len(str3)==4:
	        string3=str3
	else:
	        print('Error')

	opendap_url="https://gpm1.gesdisc.eosdis.nasa.gov/opendap/hyrax/GPM_L3/GPM_3IMERGHHE.06/"+str(mdate.tm_year)+"/"+str(julian)+"/3B-HHR-E.MS.MRG.3IMERG."+yyyymmdd+"-"+string1+"-"+string2+"."+str(string3)+".V06B.HDF5"

	username = 'ankurk017'
	password = 'AnkurKumar2020'
	session = setup_session(username, password, check_url=opendap_url)
	dataset = open_url(opendap_url, session=session)
	imerg.lat=dataset['lat'].data[slice(900,None)]
	imerg.lon=dataset['lon'].data[slice(None,1700)]
	pcp=np.squeeze(dataset['precipitationCal'].data[0,slice(None,1700),slice(900,None)])
	pcp[pcp<0]=np.nan
	imerg.pcp=pcp.T
	return imerg



def track_data(dataset,tc_cen_lon,tc_cen_lat,boundary_extent=6):
	lon_id=np.where(np.logical_and(dataset.lon>tc_cen_lon-boundary_extent, dataset.lon<tc_cen_lon+boundary_extent))[0]
	lat_id=np.where(np.logical_and(dataset.lat>tc_cen_lat-boundary_extent, dataset.lat<tc_cen_lat+boundary_extent))[0]
	pcp_crop=dataset.pcp[lat_id[0]:lat_id[-1]+1,lon_id[0]:lon_id[-1]+1]
	pcp_nan=np.empty((dataset.pcp.shape[0],dataset.pcp.shape[1]))*np.nan
	pcp_nan[lat_id[0]:lat_id[-1]+1,lon_id[0]:lon_id[-1]+1]=pcp_crop
	dataset.pcpcrop=pcp_nan
	return dataset

def plot_track(track_lon,track_lat,proj,ll_proj):
	fig, ax = plt.subplots(subplot_kw=dict(projection=proj))
	land = ax.add_feature(cfeature.LAND, facecolor='burlywood')
	coast = ax.add_feature(cfeature.COASTLINE)
	ocean = ax.add_feature(cfeature.OCEAN, facecolor='steelblue')
	country = ax.add_feature(cfeature.BORDERS, edgecolor='gray')
	gl=ax.gridlines(draw_labels=True, linestyle=':')
	plt.plot(track_lon,track_lat,color='blue', linewidth=2,transform=ccrs.Geodetic())
	return fig,ax



def mycontourf(trmm,varname):
	import matplotlib.pyplot as plt

	import cartopy.crs as ccrs
	from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER
	import matplotlib.ticker as mticker
	fig=plt.figure(figsize=(10,5))
	ax = plt.axes(projection=ccrs.PlateCarree())
	ax.set_extent([-180,180,-60,60])

	ax.coastlines(resolution="110m",linewidth=1)
	gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                  linewidth=1, color='black', linestyle='--')
	gl.xlabels_top = False
	gl.ylabels_right = False
	gl.xlines = True
#	gl.xlocator = mticker.FixedLocator([-180, -90, 0, 90, 180])
#	gl.ylocator = mticker.FixedLocator([-60, -50, -25, 0, 25, 50, 60])
	gl.xformatter = LONGITUDE_FORMATTER
	gl.yformatter = LATITUDE_FORMATTER
	gl.xlabel_style = {'size':16, 'color':'black'}
	gl.ylabel_style = {'size':16, 'color':'black'}

	plt.contourf(trmm.lon,trmm.lat,varname)
	plt.axis('equal')
	plt.colorbar()
	plt.show()
	return fig,ax
	
