#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 28 09:53:16 2020
Lab Assignment02
ThinkPython 2e, Chapter 4: Exercise 4.2
This Program draws three flowers with different number (7,10 and 20 number) of petals by using the "Turtle" module.

@author: tiwari13 (Alka Tiwari)
"""
# Importing required modules.
import turtle
from polygon import*

def petal(t, r, angle):
    """Draws a petal using two arcs.
    t: Turtle
    r: radius of the arcs
    angle: angle (degrees) that subtends the arcs
    """
    for i in range(2):
        arc(t, r, angle)
        lt(t, 180-angle)

def flower(t, n, r, angle):
    """Draws a flower with n petals.
    t: Turtle
    n: number of petals
    r: radius of the arcs
    angle: angle (degrees) that subtends the arcs
    """
    for i in range(n):
        petal(t, r, angle)
        lt(t, 360.0/n)

def draw_flower(t, length):
    """Move Turtle (t) forward (length) units without leaving a trail.
    Leaves the pen down.
    """
    pu(t)
    fd(t, length)
    pd(t)

#world = TurtleWorld()
bob= turtle.Turtle()
bob.delay = 0.01

# draw a sequence of three flowers, as shown in the book.
#draw flower with 7 petals
draw_flower(bob, -100) 
flower(bob, 7, 60.0, 60.0)

#draw flower with 10 petals
draw_flower(bob, 100)
flower(bob, 10, 40.0, 80.0)

#draw flower with 20 petals
draw_flower(bob, 100)
flower(bob, 20, 140.0, 20.0)

    

def petal(length, angle):
    ''' Draws one petal 
    
        length = length of petal
        angle = width of petal'''
    for i in range (2):                                     # Draws one petal
        turtle.circle(length,angle)
        turtle.left(180-angle)  

def flower(n, length, angle):
    ''' Draws flower using petals() function
    
        n = number of petals
        length = length of petals
        angle = width of petals'''
    for i in range (n):                                     # Draws n number of petals
        petal(length, angle)
        turtle.left(360/n)

def draw_3flowers():
    ''' Draws a sequence of 3 flowers with 7, 10, and 20 petals, respectively'''     
    flower_Set = ([7, 110, 60], [10,70,90],[20,170,30])     # n_petal, length and angle for each flower
    
    for n in range(len(flower_Set)):
        flower(flower_Set[n][0], flower_Set[n][1], flower_Set[n][2])
        turtle.up()                                         # moves turtle to the left 
        turtle.forward(210)
        turtle.pd()
           
    
draw_3flowers()