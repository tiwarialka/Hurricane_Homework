
Input file required: 2008Male00006.txt
Output file created: Georges_life.txt
Python script file: Evaluate_Raccoon_Life.txt

LIBRARY/MODULE USED:
"math" module has been used to compute square root 'sqrt'.

FUNCTION CREATED:
com_avg(lst): Compute the mean/average of a list
com_sum(lst): Compute the cumulative sum of a list
way(X1,Y1,X2,Y2):Compute the distance between two points (x1,y1) and (x2,y2)
                 by using formula; dist = sqrt((X2-X1)**2+(Y2-Y1)**2)                                         
com_dist(X, Y, dic):It takes lists of numbers as input. One list containing X coordinates and one containing Y coordinates.
It returns a list containing subsequent distances between points described by the two input lists.

The "Evaluate_Raccon_Life.py" has description of the code along with each line.






